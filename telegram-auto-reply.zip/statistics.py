#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
    Система сбора статистики и генерации отчётов
    для Telegram канала @fitnesstimer
    
    Собирает:
    - Отзывы о таймере
    - Вопросы о тренировках
    - Общую активность
    - Генерирует summary отчёты
    - Отправляет на email и в Telegram
"""

import json
import os
import requests
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime, timedelta
from pathlib import Path
from collections import defaultdict

# ============= КОНФИГУРАЦИЯ =============

STATISTICS_FILE = Path('.telegram_statistics.json')
TELEGRAM_BOT_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN')
ADMIN_EMAIL = 'admin@tabatatimer.ru'
ADMIN_TELEGRAM = '@lobanoff_pro'  # Или можно использовать chat_id

# Настройки email (нужно будет настроить SMTP)
SMTP_SERVER = os.getenv('SMTP_SERVER', 'smtp.yandex.ru')
SMTP_PORT = int(os.getenv('SMTP_PORT', '465'))
SMTP_USER = os.getenv('SMTP_USER', ADMIN_EMAIL)
SMTP_PASSWORD = os.getenv('SMTP_PASSWORD', '')


def загрузить_статистику():
    """Загружает статистику из JSON файла"""
    if STATISTICS_FILE.exists():
        try:
            with open(STATISTICS_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"⚠️ Ошибка загрузки статистики: {e}")
    return {
        'total_comments': 0,
        'total_feedback': 0,
        'total_questions': 0,
        'feedback_by_date': {},
        'questions_by_date': {},
        'comments_by_date': {},
        'last_update': None,
        'feedback_list': [],
        'questions_list': []
    }


def сохранить_статистику(статистика):
    """Сохраняет статистику в JSON файл"""
    try:
        статистика['last_update'] = datetime.now().isoformat()
        with open(STATISTICS_FILE, 'w', encoding='utf-8') as f:
            json.dump(статистика, f, ensure_ascii=False, indent=2)
        return True
    except Exception as e:
        print(f"⚠️ Ошибка сохранения статистики: {e}")
        return False


def добавить_комментарий(комментарий, тип='question'):
    """
    Добавляет комментарий в статистику
    
    Args:
        комментарий: dict с полями 'text', 'from_user', 'username', 'date', 'message_id'
        тип: 'feedback' (отзыв о таймере) или 'question' (вопрос о тренировках)
    """
    статистика = загрузить_статистику()
    дата = datetime.now().strftime('%Y-%m-%d')
    
    # Общая статистика
    статистика['total_comments'] += 1
    if тип == 'feedback':
        статистика['total_feedback'] += 1
        статистика['feedback_list'].append({
            'date': дата,
            'timestamp': datetime.now().isoformat(),
            'user': комментарий.get('from_user', 'Неизвестно'),
            'username': комментарий.get('username', ''),
            'text': комментарий.get('text', ''),
            'message_id': комментарий.get('message_id')
        })
        # Ограничиваем размер списка (последние 1000 отзывов)
        if len(статистика['feedback_list']) > 1000:
            статистика['feedback_list'] = статистика['feedback_list'][-1000:]
    else:
        статистика['total_questions'] += 1
        статистика['questions_list'].append({
            'date': дата,
            'timestamp': datetime.now().isoformat(),
            'user': комментарий.get('from_user', 'Неизвестно'),
            'username': комментарий.get('username', ''),
            'text': комментарий.get('text', ''),
            'message_id': комментарий.get('message_id')
        })
        # Ограничиваем размер списка (последние 1000 вопросов)
        if len(статистика['questions_list']) > 1000:
            статистика['questions_list'] = статистика['questions_list'][-1000:]
    
    # Статистика по датам
    if дата not in статистика['comments_by_date']:
        статистика['comments_by_date'][дата] = 0
    статистика['comments_by_date'][дата] += 1
    
    if тип == 'feedback':
        if дата not in статистика['feedback_by_date']:
            статистика['feedback_by_date'][дата] = 0
        статистика['feedback_by_date'][дата] += 1
    else:
        if дата not in статистика['questions_by_date']:
            статистика['questions_by_date'][дата] = 0
        статистика['questions_by_date'][дата] += 1
    
    сохранить_статистику(статистика)
    return статистика


def сгенерировать_summary(период_дней=7):
    """
    Генерирует summary отчёт за указанный период
    
    Args:
        период_дней: количество дней для анализа (по умолчанию 7)
    
    Returns:
        dict с summary данными
    """
    статистика = загрузить_статистику()
    дата_начала = (datetime.now() - timedelta(days=период_дней)).strftime('%Y-%m-%d')
    
    # Фильтруем данные за период
    отзывы_за_период = [
        f for f in статистика.get('feedback_list', [])
        if f.get('date', '') >= дата_начала
    ]
    
    вопросы_за_период = [
        q for q in статистика.get('questions_list', [])
        if q.get('date', '') >= дата_начала
    ]
    
    # Подсчитываем статистику по датам
    отзывы_по_датам = defaultdict(int)
    вопросы_по_датам = defaultdict(int)
    
    for отзыв in отзывы_за_период:
        отзывы_по_датам[отзыв.get('date', '')] += 1
    
    for вопрос in вопросы_за_период:
        вопросы_по_датам[вопрос.get('date', '')] += 1
    
    summary = {
        'период': f'Последние {период_дней} дней',
        'дата_отчёта': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'общая_статистика': {
            'всего_комментариев': статистика.get('total_comments', 0),
            'всего_отзывов': статистика.get('total_feedback', 0),
            'всего_вопросов': статистика.get('total_questions', 0)
        },
        'за_период': {
            'отзывов': len(отзывы_за_период),
            'вопросов': len(вопросы_за_период),
            'всего_активности': len(отзывы_за_период) + len(вопросы_за_период)
        },
        'отзывы_по_датам': dict(отзывы_по_датам),
        'вопросы_по_датам': dict(вопросы_по_датам),
        'последние_отзывы': отзывы_за_период[-10:],  # Последние 10 отзывов
        'последние_вопросы': вопросы_за_период[-10:]  # Последние 10 вопросов
    }
    
    return summary


def форматировать_summary_для_текста(summary):
    """Форматирует summary в читаемый текст"""
    текст = f"""📊 ОТЧЁТ ПО АКТИВНОСТИ TELEGRAM КАНАЛА @fitnesstimer

{summary['период']}
Дата отчёта: {summary['дата_отчёта']}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📈 ОБЩАЯ СТАТИСТИКА:
• Всего комментариев: {summary['общая_статистика']['всего_комментариев']}
• Всего отзывов о таймере: {summary['общая_статистика']['всего_отзывов']}
• Всего вопросов о тренировках: {summary['общая_статистика']['всего_вопросов']}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📅 АКТИВНОСТЬ ЗА ПЕРИОД:
• Отзывов: {summary['за_период']['отзывов']}
• Вопросов: {summary['за_период']['вопросов']}
• Всего активности: {summary['за_период']['всего_активности']}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""
    
    # Отзывы по датам
    if summary['отзывы_по_датам']:
        текст += "\n📝 ОТЗЫВЫ ПО ДАТАМ:\n"
        for дата, количество in sorted(summary['отзывы_по_датам'].items()):
            текст += f"  {дата}: {количество} отзыв(ов)\n"
    
    # Вопросы по датам
    if summary['вопросы_по_датам']:
        текст += "\n❓ ВОПРОСЫ ПО ДАТАМ:\n"
        for дата, количество in sorted(summary['вопросы_по_датам'].items()):
            текст += f"  {дата}: {количество} вопрос(ов)\n"
    
    # Последние отзывы
    if summary['последние_отзывы']:
        текст += "\n\n💬 ПОСЛЕДНИЕ ОТЗЫВЫ:\n"
        for idx, отзыв in enumerate(summary['последние_отзывы'], 1):
            текст += f"\n{idx}. {отзыв.get('date', 'N/A')} - {отзыв.get('user', 'Неизвестно')}\n"
            текст += f"   {отзыв.get('text', '')[:100]}{'...' if len(отзыв.get('text', '')) > 100 else ''}\n"
    
    # Последние вопросы
    if summary['последние_вопросы']:
        текст += "\n\n❓ ПОСЛЕДНИЕ ВОПРОСЫ:\n"
        for idx, вопрос in enumerate(summary['последние_вопросы'], 1):
            текст += f"\n{idx}. {вопрос.get('date', 'N/A')} - {вопрос.get('user', 'Неизвестно')}\n"
            текст += f"   {вопрос.get('text', '')[:100]}{'...' if len(вопрос.get('text', '')) > 100 else ''}\n"
    
    текст += "\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
    текст += "📧 Подробная статистика доступна в файле .telegram_statistics.json"
    
    return текст


def отправить_на_email(текст, тема='📊 Отчёт по активности Telegram канала'):
    """Отправляет отчёт на email"""
    if not SMTP_PASSWORD:
        print("⚠️ SMTP_PASSWORD не настроен, пропускаем отправку на email")
        return False
    
    try:
        msg = MIMEMultipart()
        msg['From'] = SMTP_USER
        msg['To'] = ADMIN_EMAIL
        msg['Subject'] = тема
        
        msg.attach(MIMEText(текст, 'plain', 'utf-8'))
        
        server = smtplib.SMTP_SSL(SMTP_SERVER, SMTP_PORT)
        server.login(SMTP_USER, SMTP_PASSWORD)
        server.send_message(msg)
        server.quit()
        
        print(f"✅ Отчёт отправлен на {ADMIN_EMAIL}")
        return True
    except Exception as e:
        print(f"❌ Ошибка отправки на email: {e}")
        return False


def отправить_в_telegram(текст, chat_id=None):
    """
    Отправляет отчёт в личный Telegram
    
    Args:
        текст: текст отчёта
        chat_id: ID чата (если не указан, используется ADMIN_TELEGRAM)
    """
    if not TELEGRAM_BOT_TOKEN:
        print("⚠️ TELEGRAM_BOT_TOKEN не настроен, пропускаем отправку в Telegram")
        return False
    
    try:
        # Если chat_id не указан, пробуем использовать username
        if not chat_id:
            # Для отправки по username нужно сначала получить chat_id через getUpdates
            # Или можно использовать другой метод
            # Пока используем прямой вызов, если chat_id известен
            print("⚠️ chat_id не указан, нужно настроить ADMIN_TELEGRAM_CHAT_ID")
            return False
        
        url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
        
        # Разбиваем длинный текст на части (лимит Telegram ~4096 символов)
        max_length = 4000
        if len(текст) > max_length:
            части = [текст[i:i+max_length] for i in range(0, len(текст), max_length)]
            for часть in части:
                params = {
                    'chat_id': chat_id,
                    'text': часть,
                    'parse_mode': 'HTML'
                }
                response = requests.post(url, json=params, timeout=10)
                if response.status_code != 200:
                    print(f"❌ Ошибка отправки в Telegram: {response.status_code}")
                    return False
        else:
            params = {
                'chat_id': chat_id,
                'text': текст,
                'parse_mode': 'HTML'
            }
            response = requests.post(url, json=params, timeout=10)
            if response.status_code != 200:
                print(f"❌ Ошибка отправки в Telegram: {response.status_code}")
                return False
        
        print(f"✅ Отчёт отправлен в Telegram (chat_id: {chat_id})")
        return True
    except Exception as e:
        print(f"❌ Ошибка отправки в Telegram: {e}")
        return False


def отправить_summary(период_дней=7, отправлять_email=True, отправлять_telegram=True, telegram_chat_id=None):
    """
    Генерирует и отправляет summary отчёт
    
    Args:
        период_дней: период для анализа
        отправлять_email: отправлять ли на email
        отправлять_telegram: отправлять ли в Telegram
        telegram_chat_id: ID чата в Telegram (если не указан, используется из env)
    """
    summary = сгенерировать_summary(период_дней)
    текст = форматировать_summary_для_текста(summary)
    
    if отправлять_email:
        отправить_на_email(текст)
    
    if отправлять_telegram:
        chat_id = telegram_chat_id or os.getenv('ADMIN_TELEGRAM_CHAT_ID')
        if chat_id:
            отправить_в_telegram(текст, chat_id)
        else:
            print("⚠️ ADMIN_TELEGRAM_CHAT_ID не настроен, пропускаем отправку в Telegram")
    
    return summary, текст


if __name__ == "__main__":
    # Тестовая генерация summary
    summary, текст = отправить_summary(период_дней=7)
    print("\n" + "="*50)
    print(текст)
    print("="*50)

